export const info = [
  {
    nome: "Exploradores do Céu",
    descricao: "Grupo dedicado à exploração e estudo do universo e astronomia.",
    integrantes: ["Alexandre", "Carolina", "Felipe", "Renata"]
  },
  {
    nome: "Mestres da Cozinha",
    descricao: "Apaixonados por gastronomia, receitas e descobertas culinárias.",
    integrantes: ["Eduardo", "Lúcia", "Thiago", "Fernanda"]
  },
  {
    nome: "Jornada Fitness",
    descricao: "Comunidadade focada em saúde, bem-estar e rotinas de treino.",
    integrantes: ["Beatriz", "Ricardo", "Lucas", "Marta"]
  },
  {
    nome: "Viajantes do Mundo",
    descricao: "Grupo de aventureiros e exploradores do mundo em busca de novas experiências.",
    integrantes: ["João", "Patrícia", "Carlos", "Sofia"]
  },
  {
    nome: "Caçadores de História",
    descricao: "Interessados em pesquisar, debater e compartilhar conhecimentos sobre a história.",
    integrantes: ["Ana", "Victor", "Gabriela", "Rafael"]
  },
];
